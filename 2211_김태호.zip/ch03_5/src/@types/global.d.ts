declare module '@fontsource/*' {}
