export type MinMaxWidthHeights = {
  minWidth?: string
  maxWidth?: string
  minHeight?: string
  maxHeight?: string
}
