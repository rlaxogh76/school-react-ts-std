export type LeftRightTopBottom = {
  left?: string
  right?: string
  top?: string
  bottom?: string
}
